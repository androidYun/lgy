package com.lgy.utilslibrary.mvp.Presenter.model;

/**
 * Created by ${lgy} on 2017/11/2210:44
 * 邮箱1343168198@qq.com
 * 描述： describe
 * 修改内容：
 */

public class TestResp {
}
