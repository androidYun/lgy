package com.lgy.utilslibrary.mvp.Presenter.model;

import com.google.gson.annotations.Expose;

/**
 * Created by ${lgy} on 2017/11/2317:05
 * 邮箱1343168198@qq.com
 * 描述： describe
 * 修改内容：
 */

public class HttpStatus {
    @Expose
    private int command;



    public int getCommand() {
        return command;
    }

    public void setCommand(int command) {
        this.command = command;
    }




}
