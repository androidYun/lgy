package com.ay.user.views.refreshlayout;

import android.support.design.widget.FloatingActionButton;

/**
 * Created by dest1 on 2015/10/21.
 */
public class ScrollFabBehavior extends FloatingActionButton.Behavior {
}
