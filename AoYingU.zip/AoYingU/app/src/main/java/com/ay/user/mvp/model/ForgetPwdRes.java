package com.ay.user.mvp.model;

/**
 * Created by ${lgy} on 2017/11/2115:26
 * 邮箱1343168198@qq.com
 * 描述： describe
 * 修改内容：
 */

public class ForgetPwdRes extends BaseRes {

}
