package com.ay.user.listener;

import com.ay.user.mvp.model.ProductListRes;

/**
 * Created by ${lgy} on 2017/11/2413:51
 * 邮箱1343168198@qq.com
 * 描述： describe
 * 修改内容：
 */

public interface SelectProductListener {

    void onSelectSuccess(ProductListRes.DataBean dataBean);
}
