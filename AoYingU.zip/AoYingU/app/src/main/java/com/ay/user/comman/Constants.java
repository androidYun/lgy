package com.ay.user.comman;

/**
 * Created by ${lgy} on 2017/11/2414:25
 * 邮箱1343168198@qq.com
 * 描述： describe
 * 修改内容：
 */

public class Constants {
    public static final String html_des = "<!DOCTYPE html><html dir=\"ltr\" lang=\"zh-cmn-Hans\"><head><meta charset=\"UTF-8\"><title>辅仁医疗</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\"><meta name=\"format-detection\" content=\"telephone=no\"><meta name=\"msapplication-tap-highlight\" content=\"no\"></head><body>";
    public static final String html_des_end = "</body></html>";
}
